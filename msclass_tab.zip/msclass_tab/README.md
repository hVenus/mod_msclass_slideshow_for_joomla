mod_msclass_slideshow_for_joomla

这是一个用于joomla!的前台图片轮播/滚动模块

特点：
*使用MSClass.js做为js库，原生的js代码，无需jQuery,Mootools等js库支持。<br />
*可自行设置所有参数。<br/>


System request: joomla 2.5 and up.

Install:
1，下载zip文件，到joomla的“扩展管理”里安装本模块。
2，到“模块管理”里配置本模块。该填的都填上。
3，编写XML文件，用于为模块提供显示所需的内容。
4，刷新前台页面，查看最终效果。




==END==
