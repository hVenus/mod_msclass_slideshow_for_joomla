<?php
 
        $temp[0]['id'] = 1;
        $temp[0]['alt'] = 'leader_name_alt';
        $temp[0]['title'] = 'leader_name_title';
        $temp[0]['image'] = 'http://joomla/images/wndjs/member/product/65/65_1345355249_6267.jpg';
        $temp[0]['url'] = 'http://joomla/';
        $temp[0]['desc'] = '';
        $temp[0]['keywords'] = '';
        
        $temp[1]['id'] = 2;
        $temp[1]['alt'] = 'leader_name_alt';
        $temp[1]['title'] = 'leader_name_title';
        $temp[1]['image'] = 'http://joomla/images/wndjs/member/product/65/65_1345355299_5784.jpg';
        $temp[1]['url'] = 'http://joomla/';
        $temp[1]['desc'] = '';
        $temp[1]['keywords'] = '';
        
        $temp[2]['id'] = 3;
        $temp[2]['alt'] = 'leader_name_alt';
        $temp[2]['title'] = 'leader_name_title';
        $temp[2]['image'] = 'http://joomla/images/wndjs/member/product/65/65_1345355337_7921.jpg';
        $temp[2]['url'] = 'http://joomla/';
        $temp[2]['desc'] = '';
        $temp[2]['keywords'] = '';
        
        $temp[3]['id'] = 4;
        $temp[3]['alt'] = 'leader_name_alt';
        $temp[3]['title'] = 'leader_name_title';
        $temp[3]['image'] = 'http://joomla/images/wndjs/member/product/65/65_1345355372_16727.jpg';
        $temp[3]['url'] = 'http://joomla/';
        $temp[3]['desc'] = '';
        $temp[3]['keywords'] = '';
        
        $temp[4]['id'] = 5;
        $temp[4]['alt'] = 'leader_name_alt';
        $temp[4]['title'] = 'leader_name_title';
        $temp[4]['image'] = 'http://joomla/images/wndjs/member/product/65/65_1345355372_19158.jpg';
        $temp[4]['url'] = 'http://joomla/';
        $temp[4]['desc'] = '';
        $temp[4]['keywords'] = '';
    


echo json_encode($temp);